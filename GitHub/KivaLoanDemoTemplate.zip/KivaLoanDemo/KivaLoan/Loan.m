//
//  Loan.m
//  KivaLoan
//
//  Created by Simon on 6/7/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import "Loan.h"

@implementation Loan

@end
