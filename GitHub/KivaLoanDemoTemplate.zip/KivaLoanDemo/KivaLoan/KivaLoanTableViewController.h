//
//  KivaLoanTableViewController.h
//  KivaLoan
//
//  Created by Simon on 5/7/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KivaLoanTableViewController : UITableViewController

@end
